import 'package:flutter/material.dart';

class RiskBanner extends StatelessWidget {
  final String riskLevel;
  final String message;

  const RiskBanner({
    super.key,
    required this.riskLevel,
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    Color bgColor = Colors.green[100]!;
    IconData icon = Icons.check_circle;
    Color iconColor = Colors.green;

    if (riskLevel == 'Medium') {
      bgColor = Colors.yellow[100]!;
      icon = Icons.warning_amber_rounded;
      iconColor = Colors.orange;
    } else if (riskLevel == 'High') {
      bgColor = Colors.red[100]!;
      icon = Icons.error;
      iconColor = Colors.red;
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(icon, color: iconColor),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "$riskLevel Risk",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: iconColor,
                ),
              ),
              Text(message),
            ],
          ),
        ],
      ),
    );
  }
}
