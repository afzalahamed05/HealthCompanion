import 'package:flutter/material.dart';

class SideBar extends StatelessWidget {
  const SideBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Quick Actions
        const Text(
          "Quick Actions",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        const SizedBox(height: 10),
        buildAction(Icons.medical_services, "Check Symptoms"),
        buildAction(Icons.location_on, "Nearby Hospitals"),
        buildAction(Icons.favorite, "Track Vitals"),
        buildAction(Icons.calendar_today, "Appointments"),
        buildAction(Icons.medication, "Medications"),
        buildAction(Icons.lightbulb, "Daily Tips"),

        const SizedBox(height: 30),

        // Daily Tips
        const Text(
          "Daily Health Tips",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        const SizedBox(height: 10),
        buildTip("Drink at least 8 glasses of water daily"),
        buildTip("Get 7-9 hours of sleep each night"),
        buildTip("Take a 10-minute walk after meals"),
        buildTip("Practice deep breathing for 5 minutes"),
      ],
    );
  }

  // Helper widget for quick actions
  Widget buildAction(IconData icon, String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, size: 20),
          const SizedBox(width: 10),
          Text(label, style: const TextStyle(fontSize: 14)),
        ],
      ),
    );
  }

  // Helper widget for tips
  Widget buildTip(String tip) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.circle, color: Colors.green, size: 10),
          const SizedBox(width: 8),
          Expanded(child: Text(tip, style: const TextStyle(fontSize: 13))),
        ],
      ),
    );
  }
}
