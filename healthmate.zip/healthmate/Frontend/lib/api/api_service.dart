import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = "http://172.16.45.135:5000";


  // ---------- SIGNUP ----------
  static Future<Map<String, dynamic>> signup({
    required String name,
    required int age,
    required String phone,
    required String email,
    required String username,
    required String password,
  }) async {
    final response = await http.post(
  Uri.parse("http://172.16.45.135:5000/api/user/register"),
  headers: {
    'Content-Type': 'application/json',
  },
  body: jsonEncode({
    "uid": "testuser123",
    "name": nameController.text,
    "age": int.parse(ageController.text),
    "phone": phoneController.text,
    "email": emailController.text,
    "username": usernameController.text,
  }),
);


    return jsonDecode(response.body);
  }

  // ---------- SEND MESSAGE TO GPT ----------
  static Future<Map<String, dynamic>> sendMessage(String message) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/gpt'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'symptoms': message}),
    );

    return jsonDecode(response.body);
  }
}
