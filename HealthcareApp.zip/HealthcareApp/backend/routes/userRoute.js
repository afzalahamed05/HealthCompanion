const express = require('express');
const router = express.Router();
const { db } = require('../services/firestore'); // ✅ Use admin Firestore

// Route to register/save user profile
router.post('/register', async (req, res) => {
  try {
    const { uid, name, age, phone, email, username } = req.body;

    if (!uid || !name || !email) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    // Using Admin SDK to write to Firestore
    await db.collection('users').doc(uid).set({
      name,
      age,
      phone,
      email,
      username,
      createdAt: new Date()
    });

    res.status(200).json({ message: 'User profile saved successfully' });
  } catch (error) {
    console.error('Error saving user:', error);
    res.status(500).json({ message: 'Error saving user profile' });
  }
});

module.exports = router;
