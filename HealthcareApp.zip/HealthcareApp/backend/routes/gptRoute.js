const express = require('express');
const router = express.Router();
const { OpenAI } = require('openai');

// ✅ Initialize OpenAI with the API key from .env
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * POST /api/gpt
 * Body: { "symptoms": "fever, headache, cough" }
 * Description: Takes symptoms from the user and returns
 *              possible illnesses, cures, and specialist recommendations.
 */
router.post('/', async (req, res) => {
  try {
    const { symptoms } = req.body;

    // Validate input
    if (!symptoms || symptoms.trim() === "") {
      return res.status(400).json({ message: 'Symptoms are required' });
    }

    console.log("Received symptoms:", symptoms);

    // Call GPT model for analysis
    const chatCompletion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content: `You are a medical assistant. Based on the user's symptoms,
                    provide:
                    1. The most likely illness or condition
                    2. Suggested home remedies or cures
                    3. Recommended specialist type (like dermatologist, cardiologist, etc.)
                    Respond concisely in JSON format with keys: illness, cure, specialist.`
        },
        {
          role: 'user',
          content: `Symptoms: ${symptoms}`
        }
      ],
    });

    // Extract GPT response
    const gptResponse = chatCompletion.choices[0].message.content;

    console.log("GPT Response:", gptResponse);

    // Return response to frontend
    res.status(200).json({ response: gptResponse });
  } catch (error) {
    console.error('GPT API Error:', error.message);
    res.status(500).json({
      message: 'Error processing GPT request',
      error: error.message,
    });
  }
});

module.exports = router;