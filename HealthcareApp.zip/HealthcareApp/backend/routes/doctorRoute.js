const express = require('express');
const axios = require('axios');
const router = express.Router();

router.get('/:specialist', async (req, res) => {
  const { specialist } = req.params;

  // Map of specializations and tags (can be extended)
  const tag = specialist.toLowerCase() === "dermatologist" ? "dermatology" : "hospital";

  const overpassQuery = `
    [out:json][timeout:25];
    (
      node["amenity"="${tag}"](12.9,80.1,13.2,80.3);
      way["amenity"="${tag}"](12.9,80.1,13.2,80.3);
      relation["amenity"="${tag}"](12.9,80.1,13.2,80.3);
    );
    out center;
  `;

  try {
    const response = await axios.post(
      'https://overpass-api.de/api/interpreter',
      overpassQuery,
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }
    );

    const hospitals = response.data.elements.map(el => ({
      name: el.tags?.name || "Unnamed",
      lat: el.lat || el.center?.lat,
      lon: el.lon || el.center?.lon,
      tags: el.tags
    }));

    res.json({ specialist, hospitals });
  } catch (error) {
    console.error("Overpass API error:", error.message);
    res.status(500).json({ error: "Failed to fetch data from OSM" });
  }
});

module.exports = router;
