const admin = require('firebase-admin');

// Middleware to protect routes
const verifyToken = async (req, res, next) => {
  try {
    const header = req.headers.authorization;

    if (!header || !header.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'No token provided or invalid format' });
    }

    const token = header.split('Bearer ')[1]; // Extract the actual token

    // Verify Firebase token
    const decodedToken = await admin.auth().verifyIdToken(token);

    // Attach user data to request object
    req.user = decodedToken;
    next();
  } catch (error) {
    console.error('Token verification failed:', error.message);
    res.status(401).json({ message: 'Unauthorized: Invalid or expired token' });
  }
};

module.exports = verifyToken;
