// ===============================================
// 📁 services/firestore.js
// ===============================================

const admin = require('firebase-admin');
const { getFirestore } = require('firebase-admin/firestore');

// ✅ Check if Firebase apps already exist
if (!admin.apps.length) {
  const serviceAccount = require('../serviceAccountKey.json');

  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

const db = getFirestore();

module.exports = { db, admin };
