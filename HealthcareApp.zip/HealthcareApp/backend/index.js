const dotenv = require('dotenv');
dotenv.config();  // ✅ Must be the first thing loaded
const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');

// Import routes
const userRoute = require('./routes/userRoute');
const gptRoute = require('./routes/gptRoute');
const doctorRoute = require('./routes/doctorRoute');

// Import middleware
const verifyToken = require('./middleware/authMiddleware'); // ✅ Token protection

// Load environment variables
dotenv.config();

// Initialize Express
const app = express();
app.use(cors());
app.use(express.json());



// ==============================
// API Routes
// ==============================

// User route - registration, login, etc.
app.use('/api/user', userRoute);

// GPT route - protected using verifyToken middleware
// Only authenticated users can access GPT for symptom analysis
app.use('/api/gpt', verifyToken, gptRoute);

// Doctor route - also protected
// Returns nearby doctors from Overpass API (OSM)
app.use('/api/doctors', verifyToken, doctorRoute);

// Root endpoint to test server
app.get('/', (req, res) => {
  res.send({ message: 'Healthcare Chatbot Backend Running!' });
});

// ==============================
// Start Server
// ==============================
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
